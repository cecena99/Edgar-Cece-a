---
title: Angular y Scully
description: 'Cómo construir un blog con Angular y Scully'
published: True
---

# Angular y Scully
Angular es un framework de Javascript robusto que podemos usar para crear aplicaciones web excelentes y de alto rendimiento.
Scully es un popular generador de sitios web estáticos que potencia Angular con características Jamstack.
Puede encontrar más sobre ellos en los siguientes enlaces:
- https://angular.io
- https://scully.io
- https://www.jamstack.org
