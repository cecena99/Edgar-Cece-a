export const environment = {
  production: true,
  apiUrl: 'https://api.openweathermap.org/data/2.5/',
  apiKey: '8ecd9e5b6e75dea1073bb058a54a671f'
};
